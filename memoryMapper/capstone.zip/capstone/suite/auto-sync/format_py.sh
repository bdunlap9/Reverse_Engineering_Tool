#!/usr/bin/bash

python3 -m black src/autosync
